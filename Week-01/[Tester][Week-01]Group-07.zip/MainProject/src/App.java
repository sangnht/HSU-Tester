import java.util.Scanner;
import Triangle.Triangle;

public class App {
    public static void main(String[] args) throws Exception {
        double sideA, sideB, sideC;

        Scanner input = new Scanner(System.in);
        System.out.print("Enter side A: ");
        sideA = input.nextDouble();
        System.out.print("Enter side B: ");
        sideB = input.nextDouble();
        System.out.print("Enter side C: ");
        sideC = input.nextDouble();

        Triangle triangle = new Triangle(sideA, sideB, sideC);
        int result = triangle.checkTriangle();

        switch (result) {
            case 0:
                System.out.println("Khong tao thanh tam giac");
                break;
            case 1:
                System.out.println("Tam giac thuong");
                break;
            case 2:
                System.out.println("Tam giac can");
                break;
            case 3:
                System.out.println("Tam giac deu");
                break;
            case 4:
                System.out.println("Tam giac vuong");
                break;
            case 5:
                System.out.println("Tam giac vuong can");
                break;
            default:
                System.out.println("Error");
                break;
        }
    }
}
